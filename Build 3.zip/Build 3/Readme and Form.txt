Hello, and welcome to my latest build of my game, Regression!

In this build I have fixed many bugs from the last build, release notes below.
I have also added a brand new enemy, the mega troll, which shoots multiple projectiles. The spawning is a little bit buggy, but he shoots rapidly so be careful!
It is now also possible to test my game on multiple difficulties too, although the descriptions of each difficulty in the choose difficulty screen are outdated.


Feel free to test how you like and leave any feedback you find.
Please also say if any UI does not scale correctly with your machine, and please give the system resolution where possible.
Thanks!

There are two waves for you to complete at the moment, the rest will be coming soon.

(Note: If you are not a University of Plymouth student, please include that in the form as it is very important!
FORM TO FILL OUT: https://forms.gle/m5sxGD7y9tt9wEk59

Release notes:
Activated Hard and Expert difficulty buttons on the main menu. Good luck!
Introduced a third enemy - the Mega troll. He takes many more hits to kill.
Reduced cooldown of the Staff of the Gods by 1s to 2s. With one power, it will become 1.5s.
Melee weapon now works again - To compensate, you can now get closer to enemies. This does mean with some larger enemies they will take up most of the screen. This will be something fixed soon.
You will no longer slide when a pause is triggered, either by the game or the player and you are still holding any movement keys.
On Expert, if upon wave completion you were using a sword and a staff is chosen, the sword will now despawn correctly. The projectile spawner will also initialise correctly too.
Exit screen now takes you to the main menu, instead of completely closing the game.
General UI fixes.
Mega Troll will no longer extinguish fires.
You can now select a weapon in Hard difficulty again.
Removed the spontaneous comet that spawned when the game was started.

Known issues:
Timers for certain powers continue while the game is paused.
... and more!